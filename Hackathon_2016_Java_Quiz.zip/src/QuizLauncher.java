
import java.awt.EventQueue;
import javax.swing.JFrame;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * 
 * @author Brian Thompson
 */
public class QuizLauncher {
    
     private static QuizModel qm = new QuizModel();
    
    
    
    
    /*MAIN*************************************************************************/
    public static void main(String[] args) {
       
        
        
    EventQueue.invokeLater(new Runnable() {
       public void run(){
         Screen frame = new Screen();
         
       }
    });
    }
}
