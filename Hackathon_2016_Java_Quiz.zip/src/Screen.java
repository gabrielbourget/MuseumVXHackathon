
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;

/**
 * 
 * @author Brian Thompson
 */
public class Screen implements ActionListener{
    private JFrame initFrame;
    private Quiz q;
    private Container content;
    private QuizModel qm;
    private int correct;
    
    public Screen(){
                
        correct=0;
        initFrame = new JFrame();
        initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        qm = new QuizModel();
        Slash splash = new Slash(this);
        
        content=initFrame.getContentPane();
        content.add(splash);
        initFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        initFrame.setUndecorated(true);
        initFrame.pack();
        initFrame.setVisible(true);
    }
    
    public void init(){
        correct=0;
        initFrame = new JFrame();
        initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        qm = new QuizModel();
        Slash splash = new Slash(this);
        
        content=initFrame.getContentPane();
        content.add(splash);
        initFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        initFrame.setUndecorated(true);
        initFrame.pack();
        initFrame.setVisible(true);
    }
    /* OVERRIDES! *****************************************************************/
    @Override
    public void actionPerformed(ActionEvent evt){
        String arg = evt.getActionCommand();
        
        if(arg.equals("OK")) {
            this.init();
        }
        //splash
        else if (arg.equals("SPLASH")) {
            content.removeAll();
            q = new Quiz(qm.question1(),this);
            content.add(q);
            content.validate();
            content.repaint();
        }
        //question1
        else if (arg.equals(qm.question1()[2])) {
            content.removeAll();
            q = new Quiz(qm.question2(),this);
            content.add(q);
            content.validate();
            content.repaint();
            correct++;
        }else if (arg.equals(qm.question1()[3])||arg.equals(qm.question1()[4])||arg.equals(qm.question1()[6])) {
            content.removeAll();
            q = new Quiz(qm.question2(),this);
            content.add(q);
            content.validate();
            content.repaint();
        }
        //question2
        else if (arg.equals(qm.question2()[2])) {
            content.removeAll();
            q = new Quiz(qm.question3(),this);
            content.add(q);
            content.validate();
            content.repaint();
            correct++;
        }else if (arg.equals(qm.question2()[3])||arg.equals(qm.question2()[5])||arg.equals(qm.question2()[6])) {
            content.removeAll();
            q = new Quiz(qm.question3(),this);
            content.add(q);
            content.validate();
            content.repaint();
        }
        //question3
        else if (arg.equals(qm.question3()[2])) {
            content.removeAll();
            q = new Quiz(qm.question4(),this);
            content.add(q);
            content.validate();
            content.repaint();
            correct++;
        }else if (arg.equals(qm.question3()[3])||arg.equals(qm.question3()[4])||arg.equals(qm.question3()[5])) {
            content.removeAll();
            q = new Quiz(qm.question4(),this);
            content.add(q);
            content.validate();
            content.repaint();
        }
        //question4
        else if (arg.equals(qm.question4()[2])) {
            content.removeAll();
            q = new Quiz(qm.question5(),this);
            content.add(q);
            content.validate();
            content.repaint();
            correct++;
        }else if (arg.equals(qm.question4()[3])) {
            content.removeAll();
            q = new Quiz(qm.question5(),this);
            content.add(q);
            content.validate();
            content.repaint();
        }
        //question5
        else if (arg.equals(qm.question5()[2])) {
            correct++;
            content.removeAll();
            Result res = new Result(correct, this);
            content.add(res);
            content.validate();
            content.repaint();
        }else if (arg.equals(qm.question5()[4])||arg.equals(qm.question5()[5])||arg.equals(qm.question5()[6])) {
            content.removeAll();
            Result res = new Result(correct, this);
            content.add(res);
            content.validate();
            content.repaint();
        }
    }//end override
}
