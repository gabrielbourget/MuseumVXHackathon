
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * 
 * @author Brian Thompson
 */
public class Result extends JPanel{
    private  ActionListener a;
    
    public Result(int result, ActionListener a){
       this.a=a;
            
        
        JPanel page = new JPanel();
        page.setLayout(new BorderLayout());
        page.setBackground(Color.WHITE);
        //image
        JPanel imagePanel = new JPanel();
        JLabel image = new JLabel(new ImageIcon("ResultImage.jpg"));
        imagePanel.add(image);
        imagePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        //string
        //JPanel stringPanel = new JPanel();
        JLabel stringL = new JLabel("You answered ");
        stringL.setFont(new Font("Serif", Font.PLAIN, 40));
        //stringPanel.add(stringL);
        JLabel stringL2 = new JLabel("/5 correctly!");
        stringL2.setFont(new Font("Serif", Font.PLAIN, 40));
        
        //result
        Integer r = result;
        JPanel resultPanel = new JPanel();
        JLabel resultL = new JLabel(r.toString());
        resultL.setFont(new Font("Serif", Font.PLAIN, 40));
        resultPanel.add(stringL);
        resultPanel.add(resultL);
        resultPanel.add(stringL2);
        
        //button
        JButton button = new JButton("OK");
        button.addActionListener(a);
        button.setActionCommand("OK");
        
        page.add(imagePanel, BorderLayout.NORTH);
        //page.add(stringPanel, BorderLayout.CENTER);
        page.add(resultPanel, BorderLayout.CENTER);
        page.add(button, BorderLayout.SOUTH);
        add(page);
        
        SqlController sql = new SqlController(null);
        sql.setId("2919b9afb42411e688df06dbd9504c95");
        sql.initDatabase();
        sql.updateUserQuizResult(result);
        sql.updateUserStatus();
        sql.closeDatabase();
        sql.clearId();
    }
    
}
