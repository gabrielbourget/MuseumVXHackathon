/**
 * 
 * @author Brian Thompson
 */
public class QuizModel {
    /* Questions */
    private int qnum = 5;
    private String[] question1;
    private String[] question2;
    private String[] question3;
    private String[] question4;
    private String[] question5;
    
    public int getQNum(){
        return qnum;
    }
    
    /*Question1*/
    public String[] question1(){
        question1 = new String[7];
        question1[0]= "How many expeditions did John Franklin set out on?";//question
        question1[1]= "HMS-terror-drawing.jpg";//image name
        question1[2]= "3";//answer
        question1[3]= "2";
        question1[4]= "1";
        question1[5]= "3";//correct
        question1[6]= "5";
        
        return question1;
    }
        
        /*Question2*/
    public String[] question2(){
        question2 = new String[7];
        question2[0]= "What nutrient or vitamin is instrumental to preventing Scurvy?";
        question2[1]= "Missing Teeth.jpg";//image
        question2[2]= "Vitamin C";//answer
        question2[3]= "Riboflavin";
        question2[4]= "Vitamin C";//correct
        question2[5]= "Vitamin B12";
        question2[6]= "All of the above";
        
        return question2;
    }
    
        /*Question3*/
    public String[] question3(){
        question3 = new String[7];
        question3[0]= "What type of knot is this?";//question
        question3[1]= "clove_hitch.jpg";//image
        question3[2]= "Clove Hitch Knot";//answer
        question3[3]= "Bowline Knot";
        question3[4]= "Cleat Hitch Knot";
        question3[5]= "Alpine Butterfly Loop";
        question3[6]= "Clove Hitch Knot";//correct
       
        return question3;
    }
    
        /*Question4*/
    
    public String[] question4(){
        question4 = new String[5];
        question4[0]= "The Franklin Expeditions seeked to explore the North East Passage";//question
        question4[1]= "HMSErebus.jpg";//image
        question4[2]= "False";//answer
        question4[3]= "True";
        question4[4]= "False";//correct
     
        return question4;
    }
        /*Question5*/
    public String[] question5(){
        question5 = new String[7];
        question5[0]= "The back of a ship is referred to as:";//question
        question5[1]= "shipStern.jpg";//image
        question5[2]= "Stern";//answer
        question5[3]= "Stern";//correct
        question5[4]= "Port";
        question5[5]= "Starboard";
        question5[6]= "Keel";
        
        return question5;
    }
}
