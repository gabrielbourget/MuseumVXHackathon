
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SqlController {

    private String kioskName;
    private String id;
    private Connection connection;
    private Callback listener;
    
    public SqlController(String kioskName){
        this.kioskName = kioskName;
    }
    
    public SqlController(String kioskName, Callback listener){
        this.kioskName = kioskName;
        this.listener = listener;
    }
    
    public boolean initDatabase(){
        ConnectionBuilder newconnection = new ConnectionBuilder(
                        "hive1", 
                        "hive1", 
                        "104.131.92.40", 
                        "3306", 
                        "mysql", 
                        "hivedata"
                );
        try {
            connection = newconnection.getConnection();
            return true;
        } catch (SQLException ex) {
            ex.printStackTrace();
            connection = null;
            return false;
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
            connection = null;
            return false;
        }
    }
    
    public void setId(String id){
        this.id = id;
    }
    
    public void updateUserQuizResult(int result){
        if (id == null) return;
        
        try {
            Statement statement = connection.createStatement();
            int r = statement.executeUpdate("UPDATE `exhibits` SET `QUIZ_SCORE`= " 
                    + result + ",`done_quiz`= 1 WHERE `User_id`= '" + id + "'");
            System.out.println("Update quiz result: " + r);
        } catch (SQLException ex) {
            System.out.println("" + ex.getMessage());
        } 
    }
    
    public void updateUserEmail(String email){
        if (id == null) return;
        
        try {
            Statement statement = connection.createStatement();
            int r = statement.executeUpdate("UPDATE `users` SET `email`= '" + email 
                    + "' WHERE `User_id`= '" + id + "' ");
            System.out.println("Update email: " + r);
            listener.call(true);
        } catch (SQLException ex) {
            System.out.println("" + ex.getMessage());
            listener.call(false);
        }
        
    }
    
    public void updateUserStatus(){
        if (id == null) return;

        try {
            Statement statement = connection.createStatement();
            int r = statement.executeUpdate("UPDATE `users` SET `End_time`= NOW(),"
                    + "`Last_visit`= NOW(),`Num_visit`= `Num_visit` + 1 "
                    + "WHERE `User_id`= '"+ id +"'");
            System.out.println("Update user status: " + r);
        } catch (SQLException ex) {
            System.out.println("" + ex.getMessage());
        }
    }
    
    public void clearId(){
        id = null;
    }
    
    public void closeDatabase() {
        try {
            if (connection != null){
                System.out.println("Closing Database Connection.");
                connection.close();
            }
        } catch (SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    public boolean isConnected(){
        return connection != null;
    }
    
}
