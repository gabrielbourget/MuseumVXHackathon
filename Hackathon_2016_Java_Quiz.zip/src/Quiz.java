
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

/**
 * 
 * @author Brian Thompson
 */
public class Quiz extends JPanel{


    //fields
    private ActionListener a;
    private String answer;
    private JLabel q;
    private final Icon buttonImage = new ImageIcon("boat-wheel.jpg");
    
    
    
    public Quiz(String[] question, ActionListener a){
        this.a=a;
        add(pageBuilder(question));
        
        answer = question[2];
        
        

    }//end constructor
    
    public JPanel pageBuilder(String[] question){
        JPanel page = new JPanel();
        page.setBackground(Color.WHITE);
        
        page.setLayout(new BorderLayout());
        JPanel imagePanel;
        JPanel questionPanel;
        JPanel answerPanel;
        q = new JLabel(question[0]);
        JLabel image;
    
        //image
        imagePanel = new JPanel();
        image = new JLabel(new ImageIcon(question[1]));
        imagePanel.add(image);
        imagePanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        //question
        questionPanel = new JPanel();
        q.setFont(new Font("Serif", Font.PLAIN, 40));
        questionPanel.add(q);
        
        //answer
        answerPanel = new JPanel(new GridLayout(2,2,5,5));//gridlayout of 2x2 with gaps of 5
        for(int i = 3; i < question.length; i++){
            answerPanel.add(answerBuilder(i,question[i]));
        }
        
        page.add(imagePanel, BorderLayout.NORTH);
        page.add(questionPanel, BorderLayout.CENTER);
        page.add(answerPanel, BorderLayout.SOUTH);
        return page;
    }//end pageBuilder
    
    /*Button Builder*/
    public JPanel answerBuilder(int i,String name){
        JPanel answerPane = new JPanel();
        JButton button = new JButton(name,buttonImage);
        button.setBorderPainted(false);
        button.setBackground(Color.WHITE);
        button.setFont(new Font("Serif", Font.PLAIN, 25));
        button.addActionListener(a);
        answerPane.add(button);
        
        return answerPane;
    }
    
    
}//end class

