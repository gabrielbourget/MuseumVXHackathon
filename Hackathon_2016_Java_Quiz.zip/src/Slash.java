
import java.awt.BorderLayout;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * 
 * @author Brian Thompson
 */
public class Slash extends JPanel{
    private  ActionListener a;
    
    public Slash(ActionListener a){
       this.a=a;
            
        
        JPanel page = new JPanel();
        
        //button
        JButton button = new JButton(new ImageIcon("QuizTriggerScreen.jpg"));
        button.addActionListener(a);
        button.setActionCommand("SPLASH");
        button.setBorder(BorderFactory.createEmptyBorder());

        
        
        page.add(button, BorderLayout.CENTER);
        add(page);
        
    }
    
}
