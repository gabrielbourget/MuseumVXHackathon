/*Author: Cameron Rice
 * Date: 27, Nov 2016*/

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.TimeUnit;

import javax.swing.JFrame;

public class Screen implements ActionListener, Callback{
	
	private JFrame initFrame;
	private Login login;
	private ConfirmationScreen confirm;
	private SqlController sql;
	private Container content;
	private boolean success;
	
	public Screen(){
					
		initFrame = new JFrame("TEST AREA");
    	initFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	
    	login = new Login(this);
    	
    	sql = new SqlController(null, this);
    	
    	content = initFrame.getContentPane();
    	
		content.add(login.getInitPanel());
    	
    	initFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
    	initFrame.setUndecorated(true);
    	
     	initFrame.pack();
    	initFrame.setVisible(true);
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getActionCommand() == "ENTER"){

			sql.initDatabase();
			sql.setId("2919b9afb42411e688df06dbd9504c95");
			sql.updateUserEmail(login.field.getText());

			if(success = true){

				sql.closeDatabase();
				content.removeAll();			 		
				confirm = new ConfirmationScreen(this);
				content.add(confirm.getPanel());
				content.validate();;
				content.repaint();

			}

		}else if(e.getActionCommand() == "OK"){
			content.removeAll();			 		
			login = new Login(this);
			content.add(login.getInitPanel());
			content.validate();;
			content.repaint();
		}
		else{
			if(e.getActionCommand() == "BACKSPACE"){
				if(login.field.getText().length() != 0){
					
				
				login.field.setText(login.field.getText().substring(0, login.field.getText().length() - 1));
				}
			}
			else{
				login.field.setText(login.field.getText() + e.getActionCommand());
			}

		}
		



	}

	@Override
	public void call(boolean success) {
		this.success = success;
	}
	
}
