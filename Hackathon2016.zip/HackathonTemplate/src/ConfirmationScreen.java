/*Author: Cameron Rice
 * Date: 27, Nov 2016*/

import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class ConfirmationScreen{

	private JPanel panel;
	private ActionListener a;
	
	public ConfirmationScreen(ActionListener a){
		
		this.a = a;
		createConfirmation();
		
	}
	
	public void createConfirmation(){
		
		panel = new JPanel();
		panel.setLayout(new GridLayout(2,1));
		Font fnt = new Font("Serif", Font.BOLD, 50);
		
		JLabel label = new JLabel("Success! Email Added to database!");
		label.setFont(fnt);
		label.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(label);
		
		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());
		UIButton ok = new UIButton("OK","./assets/btn_template.png","./assets/btn_template_dn.png", 200, 100);
		ok.addActionListener(a);
		
		buttonPanel.add(ok);
		
		panel.add(buttonPanel);
		
	}
	
	public JPanel getPanel(){
		return panel;
	}
		
}
