/*Author: Cameron Rice
 * Date: 27, Nov 2016*/

import java.awt.Container;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class Main {
	
	
	public static void main(String [] args){


		java.awt.EventQueue.invokeLater(new Runnable() {

	        public void run() {
	        	  
	        	
	        	
	        	Screen mainsc = new Screen();
	        	
	     /*   	frame.setResizable(true);
	        	frame.setLocationByPlatform(true);*/
	        	      	
	        	
	        }
	    });
	}

}
