/*Author: Cameron Rice
 * Date: 27, Nov 2016*/

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.SwingConstants;

public class UIButton extends JButton{

	private static final long serialVersionUID = 1L;

	public UIButton(String btnChar, String btnimg, String btnPressedimg, int sizeX, int sizeY){
		

		if(btnChar == "BACKSPACE"){
			
			this.setPreferredSize(new Dimension(sizeX + 80, sizeY));
			this.setMaximumSize(new Dimension(sizeX + 80, sizeY));
			
			ImageIcon imgA = new ImageIcon(btnimg);
			Image imgB = imgA.getImage().getScaledInstance(sizeX + 80, sizeY, java.awt.Image.SCALE_SMOOTH);
			imgA = new ImageIcon(imgB);
			
			this.setIcon(imgA);
			
			imgA = new ImageIcon(btnPressedimg);
			imgB = imgA.getImage().getScaledInstance(sizeX + 80, sizeY, java.awt.Image.SCALE_SMOOTH);
			imgA = new ImageIcon(imgB);
			
			this.setPressedIcon(imgA);
		}
		else{
			
			this.setPreferredSize(new Dimension(sizeX, sizeY));
			this.setMaximumSize(new Dimension(sizeX, sizeY));
			
			ImageIcon imgA = new ImageIcon(btnimg);
			Image imgB = imgA.getImage().getScaledInstance(sizeX, sizeY, java.awt.Image.SCALE_SMOOTH);
			imgA = new ImageIcon(imgB);
			
			this.setIcon(imgA);
			
			imgA = new ImageIcon(btnPressedimg);
			imgB = imgA.getImage().getScaledInstance(sizeX, sizeY, java.awt.Image.SCALE_SMOOTH);
			imgA = new ImageIcon(imgB);
			
			this.setPressedIcon(imgA);
		}

		
		this.setBackground(Color.WHITE);
		
		this.setActionCommand(btnChar);
		
		this.setText(btnChar);
		this.setFont(new Font("Serif", Font.BOLD, 20));
		this.setVerticalTextPosition(SwingConstants.CENTER);
		this.setHorizontalTextPosition(SwingConstants.CENTER);
		
		this.setOpaque(true);
		this.setContentAreaFilled(false);
		this.setBorderPainted(false);
		
		/*E6192B*/
	}
	
}
