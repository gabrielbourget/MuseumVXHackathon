/*Author: Cameron Rice
 * Date: 27, Nov 2016*/

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

public class Login{

	private static final long serialVersionUID = 1L;
	protected static TextField field;
	public JPanel loginSc;
	private	boolean enterPressed;
	private ActionListener a;

	public Login(ActionListener a){
		
		this.a = a;
		createPanel();
		
	}
	
	public void createPanel(){
		
	String keys[][] = {	{"1","2","3","4","5","6","7","8","9","0",},
						{"Q","W","E","R","T","Y","U","I","O","P", "BACKSPACE"},
						{"A","S","D","F","G","H","J","K","L"},
						{"-","_","Z","X","C","V","B","N","M",".","@"}
					  };
	
	loginSc = new JPanel();
	
	loginSc.setPreferredSize(new Dimension(100,100));
	loginSc.setSize(new Dimension(500,500));
	loginSc.setLayout(new BorderLayout());
	
	JPanel textArea = new JPanel();
	textArea.setLayout(new GridLayout(2,1));
	loginSc.add(textArea, BorderLayout.NORTH);
	
	JLabel email = new JLabel();
	email.setFont(new Font("Serif", Font.PLAIN, 50));
	email.setHorizontalAlignment(SwingConstants.CENTER);
	email.setText("Enter your E-mail Address");
	textArea.add(email);
	
	field = new TextField();
	field.setEditable(true);
	field.setFont(new Font("Serif", Font.PLAIN, 50));
	textArea.add(field);
	
	textArea.setBorder(BorderFactory.createEmptyBorder(150, 0, 0, 0));
	
	JPanel osk = new JPanel();
	osk.setLayout(new GridLayout(5,1));
	loginSc.add(osk, BorderLayout.SOUTH);
	
	JPanel oskRow1 = new JPanel();
	oskRow1.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
	osk.add(oskRow1);
	
	JPanel oskRow2 = new JPanel();
	oskRow2.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
	osk.add(oskRow2);
	
	JPanel oskRow3 = new JPanel();
	oskRow3.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
	osk.add(oskRow3);
	
	JPanel oskRow4 = new JPanel();
	oskRow4.setLayout(new FlowLayout(FlowLayout.CENTER,1,1));
	osk.add(oskRow4);
	
	for(int i = 0; i < 10; i++){
		UIButton btn = new UIButton(keys[0][i],"./assets/btn_template.png", "./assets/btn_template_dn.png", 150, 100);
		btn.addActionListener(a);
		oskRow1.add(btn);
	}
	
	for(int i = 0; i < 11; i++){
		UIButton btn = new UIButton(keys[1][i],"./assets/btn_template.png", "./assets/btn_template_dn.png", 150, 100);
		btn.addActionListener(a);
		oskRow2.add(btn);
	}
	
	for(int i = 0; i < 9; i++){
		UIButton btn = new UIButton(keys[2][i],"./assets/btn_template.png", "./assets/btn_template_dn.png", 150, 100);
		btn.addActionListener(a);
		oskRow3.add(btn);
	}
	
	for(int i = 0; i < 11; i++){
		UIButton btn = new UIButton(keys[3][i],"./assets/btn_template.png", "./assets/btn_template_dn.png", 150, 100);
		btn.addActionListener(a);
		oskRow4.add(btn);
	}
	
	JPanel oskEnter = new JPanel();
	oskEnter.setLayout(new BorderLayout());
	osk.add(oskEnter);
	
	UIButton enter = new UIButton("ENTER","./assets/btn_template.png", "./assets/btn_template_dn.png", 200, 100);
	enter.addActionListener(a);
	oskEnter.add(enter, BorderLayout.EAST);
	
	osk.setBorder(BorderFactory.createEmptyBorder(20,0,50,20));


	}

	
	public JPanel getInitPanel(){
		return this.loginSc;
	}
	
	public boolean isEnterPressed(){
		return enterPressed;
	}
}
