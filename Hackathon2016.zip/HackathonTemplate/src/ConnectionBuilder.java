/*Author: Brandon Keohane
 * Date: 27, Nov 2016*/

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnectionBuilder {
	private String userName, password, serverName, portNumber, dbms, dbName;
	
	public ConnectionBuilder(String userName, String password, String serverName,String portNumber, String dbms,  String dbName){
		this.userName = userName;
		this.password = password;
		this.portNumber = portNumber;
		this.dbms = dbms;
		this.dbName = dbName;
		this.serverName = serverName;
	}
	
	public Connection getConnection() throws SQLException, ClassNotFoundException {
            
            String db_url = "jdbc:" + this.dbms + "://" + this.serverName + "/" + dbName + "?";
            
            System.out.println(db_url);
            
            Class.forName("com.mysql.jdbc.Driver");
	    Connection conn = null;

	    if (this.dbms.equals("mysql")) {
                System.out.println("Connecting to database");
	    	conn = DriverManager.getConnection( db_url, userName, password);
                
	    }
            
	    System.out.println("Connected to database");
	    return conn;
	}

}
